"use client";

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

export default function PromiseDay({
  onComplete,
}: {
  onComplete: () => void;
}) {
  const [showMessage, setShowMessage] = useState(false);
  const completed = useRef(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowMessage(true);

      if (!completed.current) {
        completed.current = true;
        setTimeout(onComplete, 2500);
      }
    }, 2600);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="day-content">
      {/* Promise Visual */}
      <div className="promise-visual">
        <motion.div
          className="promise-line left"
          initial={{ x: -60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.6, ease: "easeOut" }}
        />

        <motion.div
          className="promise-line right"
          initial={{ x: 60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.6, ease: "easeOut" }}
        />
      </div>

      {/* Message */}
      {showMessage && (
        <motion.p
          className="day-message"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2 }}
        >
          I can’t promise that everything will be easy.
          <br /><br />
          But I can promise that I’ll stay.
          <br />
          On the good days.
          <br />
          And especially on the hard ones.
          <br /><br />
          I choose you —  
          not just when it’s simple,  
          but when it actually matters.
        </motion.p>
      )}
    </div>
  );
}
