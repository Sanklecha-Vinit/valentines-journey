export const DAYS = [
  {
    id: 1,
    title: "Rose Day",
    subtitle: "Where it quietly begins",
    date: "2026-02-07",
  },
  {
    id: 2,
    title: "Propose Day",
    subtitle: "Something I’ve known for a while",
    date: "2026-02-08",
  },
  {
    id: 3,
    title: "Chocolate Day",
    subtitle: "A little warmth, just because",
    date: "2026-02-09",
  },
  {
    id: 4,
    title: "Teddy Day",
    subtitle: "Comfort you can feel",
    date: "2026-02-10",
  },
  {
    id: 5,
    title: "Promise Day",
    subtitle: "Not words — intentions",
    date: "2026-02-11",
  },
  {
    id: 6,
    title: "Hug Day",
    subtitle: "A place to rest",
    date: "2026-02-12",
  },
  {
    id: 7,
    title: "Kiss Day",
    subtitle: "Closeness without distance",
    date: "2026-02-13",
  },
  {
    id: 8,
    title: "Valentine’s Day",
    subtitle: "A love letter that took years to write",
    date: "2026-02-14",
  },
];

