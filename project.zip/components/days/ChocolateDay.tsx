"use client";

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

export default function ChocolateDay({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const hasRun = useRef(false);

  useEffect(() => {
    if (hasRun.current) return;
    hasRun.current = true;

    const timers = [
      setTimeout(() => setStep(1), 1200),
      setTimeout(() => setStep(2), 2800),
      setTimeout(() => onComplete(), 11000),
    ];

    return () => {
      timers.forEach(clearTimeout);
    };
  }, [onComplete]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-amber-950 via-amber-900 to-yellow-900 px-6 text-center">
      <div className="max-w-lg">
        <div className="relative h-64 flex items-center justify-center mb-12">
          {/* Left chocolate */}
          <motion.div
            className="absolute w-32 h-48 bg-gradient-to-br from-amber-800 to-amber-950 rounded-lg shadow-2xl"
            initial={{ x: 0 }}
            animate={step >= 1 ? { x: -60 } : { x: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <div className="absolute inset-0 grid grid-cols-3 gap-1 p-2">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="bg-amber-900/40 rounded-sm" />
              ))}
            </div>
          </motion.div>

          {/* Right chocolate */}
          <motion.div
            className="absolute w-32 h-48 bg-gradient-to-br from-amber-800 to-amber-950 rounded-lg shadow-2xl"
            initial={{ x: 0 }}
            animate={step >= 1 ? { x: 60 } : { x: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <div className="absolute inset-0 grid grid-cols-3 gap-1 p-2">
              {[...Array(9)].map((_, i) => (
                <div key={i} className="bg-amber-900/40 rounded-sm" />
              ))}
            </div>
          </motion.div>

          {/* Heart */}
          {step >= 1 && (
            <motion.div
              className="absolute text-8xl z-10"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.8, duration: 1, type: "spring", bounce: 0.6 }}
            >
              ❤️
            </motion.div>
          )}
        </div>

        {step >= 2 && (
          <div className="text-amber-100 text-base leading-relaxed space-y-5">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
              className="text-lg"
            >
              Some things are sweet on their own.
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5, duration: 1 }}
            >
              But sharing them with you makes them unforgettable.
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 3, duration: 1 }}
              className="text-amber-50 text-lg pt-4"
            >
              Like chocolate that melts —
              <br />
              <span className="text-xl font-light">you make everything softer, warmer, better.</span>
            </motion.p>
          </div>
        )}
      </div>
    </div>
  );
}
